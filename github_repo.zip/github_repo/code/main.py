import io
from fastapi import FastAPI, File, UploadFile
from PIL import Image
from ultralytics import YOLO
import uvicorn
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load model with much lower confidence threshold
model = YOLO('best.pt')
model.conf = 0.1  # Lower confidence threshold significantly from default 0.5 to 0.1

app = FastAPI(title="Blueprint Object Detection API")

@app.get("/")
def read_root():
    return {"message": "Welcome! POST to /detect with an image."}

@app.post("/detect")
async def detect_objects(file: UploadFile = File(...)):
    try:
        contents = await file.read()
        image = Image.open(io.BytesIO(contents)).convert("RGB")
        
        # Log image details for debugging
        logger.info(f"Processing image: {file.filename}, size: {image.size}")
        
        # Run inference with explicit parameters and very low confidence
        results = model(image, conf=0.1, iou=0.45, verbose=True)
        
        detections_output = []
        if results:
            result = results[0]
            boxes = result.boxes
            img_width, img_height = image.size
            
            # Log detection count
            logger.info(f"Found {len(boxes)} detections")
            
            for box in boxes:
                class_id = int(box.cls[0])
                label = model.names[class_id]
                confidence = float(box.conf[0])
                x_min, y_min, x_max, y_max = box.xyxy[0].tolist()
                bbox_x = x_min
                bbox_y = y_min
                bbox_w = x_max - x_min
                bbox_h = y_max - y_min
                
                # Log each detection
                logger.info(f"Detection: {label}, confidence: {confidence}")
                
                detections_output.append({
                    "label": label,
                    "confidence": round(confidence, 3),
                    "bbox": [round(bbox_x,1), round(bbox_y,1), round(bbox_w,1), round(bbox_h,1)]
                })
        
        return {"predictions": detections_output}
    except Exception as e:
        logger.error(f"Error processing image: {str(e)}")
        return {"error": str(e)}

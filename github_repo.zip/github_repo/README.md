# Blueprint Detection Model

This repository contains a YOLOv8-based object detection model for identifying doors and windows in architectural blueprints.

## Live API

The model is deployed as a public API on Hugging Face Spaces:

[https://huggingface.co/spaces/RoshanTheCoder/blueprint-detector](https://huggingface.co/spaces/RoshanTheCoder/blueprint-detector)

## API Usage

You can test the API using curl:

```bash
curl -X POST -F "file=@path/to/your/blueprint.jpg" https://roshanthecoder-blueprint-detector.hf.space/detect
```

### Example Response

```json
{
  "predictions": [
    {
      "label": "door",
      "confidence": 0.876,
      "bbox": [120.5, 250.2, 45.1, 90.3]
    },
    {
      "label": "window",
      "confidence": 0.765,
      "bbox": [320.1, 150.8, 60.2, 30.5]
    }
  ]
}
```

## Classes

The model detects two classes in architectural blueprints:

1. **Door** - Entrances and exits in the blueprint, typically represented by arcs or rectangular openings in walls
2. **Window** - Window openings in the blueprint, typically represented by rectangular shapes in walls

## Repository Contents

- `best.pt`: The trained YOLOv8 model file
- `dataset.zip`: Complete labeled dataset (images + annotations in YOLO format)
- `code/main.py`: FastAPI code for the detection API
- `code/Dockerfile`: Container configuration for deployment
- `code/requirements.txt`: Python dependencies

## Implementation Notes

The model was trained using YOLOv8 on a dataset of architectural blueprints. The confidence threshold has been set to 0.1 to improve detection sensitivity for line-based blueprint drawings.

The API is currently deployed on Hugging Face Spaces and may require further optimization for production use.

## Local Development

To run the API locally:

1. Clone this repository
2. Install dependencies: `pip install -r code/requirements.txt`
3. Run the API: `uvicorn code.main:app --host 0.0.0.0 --port 8000`
4. Test with: `curl -X POST -F "file=@path/to/blueprint.jpg" http://localhost:8000/detect`

import io
from fastapi import FastAPI, File, UploadFile
from PIL import Image
from ultralytics import YOLO
import uvicorn

model = YOLO('best.pt') # Assumes best.pt is in the same directory in the Space
app = FastAPI(title="Blueprint Object Detection API")

@app.get("/")
def read_root():
    return {"message": "Welcome! POST to /detect with an image."}

@app.post("/detect")
async def detect_objects(file: UploadFile = File(...)):
    contents = await file.read()
    image = Image.open(io.BytesIO(contents)).convert("RGB")
    results = model(image)
    detections_output = []
    if results:
        result = results[0]
        boxes = result.boxes
        img_width, img_height = image.size
        for box in boxes:
            class_id = int(box.cls[0])
            label = model.names[class_id]
            confidence = float(box.conf[0])
            x_min, y_min, x_max, y_max = box.xyxy[0].tolist()
            bbox_x = x_min
            bbox_y = y_min
            bbox_w = x_max - x_min
            bbox_h = y_max - y_min
            detections_output.append({
                "label": label,
                "confidence": round(confidence, 3),
                "bbox": [round(bbox_x,1), round(bbox_y,1), round(bbox_w,1), round(bbox_h,1)]
            })
    return {"predictions": detections_output}